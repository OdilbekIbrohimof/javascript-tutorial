// let userNum = +prompt("son kiriting");
// if (userNum == 1) {
//   console.log("Assalomu aleykum");
// } else if (userNum == 2) {
//   console.log("qalaysiz");
// } else if (userNum == 3) {
//   console.log("bugun havo yaxshi");
// } else {
//   console.log("bunday son yoooooq");
// }

// analog >> bir xil

// switch (userNum) { // if (userNum == case)
//   case 1: // if (userNum == 1) {console.log("Assalomu aleykum");}
//     console.log("Assalomu aleykum");
//     break // agar break qoyilmasa ozidan kayingi case lar ham true qaytarib barchasi ishlab ketadi 
//   case 2:
//     console.log("qalaysiz");
//     break
//   case 3:
//     console.log("bunday son yoooooq");
//     break
//   case 4:
//     console.log("Juda issiq emasmi");
//     break
//   default: //else
//     console.log("bunday son yo'q");
//     break
// }

// let name = prompt("enter your name")
// switch (name) {
//   case "abdullo":
//     alert(name)
//     break
//   case "hasanboy":
//     alert(404)
//     break
//   default:
//     alert("Write something")
// }

// alert("task 1")
// let userNum = prompt()
// let num = userNum[0]+userNum[1]
// switch (num) {
//   case "33" :
//     console.log("humans");
//     break
//   case "88":
//     console.log("mobiuz");
//     break
//   case "90":
//     console.log("beeline");
//     break
//   case "91":
//     console.log("beeline");
//     break
//   case "93":
//     console.log("usell");
//     break
//   case "97":
//     console.log("mobiuz");
//     break
//   case "99":
//     console.log("uzmobile");
//     break
//   default:
//     console.log("bunday company mavjud emas");
// }

// alert("task 2")
// let inputNum = prompt("son kiriting")
// for (let i = 0; i < inputNum.length; i++){
//   myNum = inputNum[i]
// }
// let check = false
// check = myNum == 0 || myNum == 2 || myNum == 4 || myNum == 6 || myNum == 8
// switch (check) {
//   case true:
//     console.log(inputNum ** 2);
//     break
//   default :
//     console.log(inputNum ** 3);
//     break
// }

// alert(3)
let kharfi = prompt("katakchani harfni kiriting");
let ksoni = +prompt("katakchani sonini kiriting")
if (kharfi == "b" || kharfi == "d" || kharfi =="f" || kharfi == "h" && ksoni == (ksoni % 2 == 0) ) {
  console.log("qora katakcha");
}else if (kharfi == "b" || kharfi == "d" || kharfi == "f" || kharfi == "h" && ksoni == (ksoni % 2 != 0)) {
  console.log("oq katakcha");
}else if (kharfi == "b" || kharfi == "d" || kharfi == "f" || kharfi == "h" && ksoni == 1) {
  console.log("oq katakcha");
} else if (kharfi == "a" || kharfi == "c" || kharfi == "e" || kharfi == "g" && ksoni == (ksoni % 2 == 0)) {
  console.log("oq katakcha");
} else if (kharfi == "a" || kharfi == "c" || kharfi == "e" || kharfi == "g" && ksoni == 1) {
  console.log("qora katakcha");
} else if (kharfi == "a" || kharfi == "c" || kharfi == "e" || kharfi == "g" && ksoni == (ksoni % 2 != 0)) {
  console.log("qora katakcha");
} else {
  console.log("bunday katakcha yoq");
}


// let katakcha = prompt("katakchani kiriting")
// switch (katakcha) {
//   case 
// }