// alpha.split("") >>> split biron narsani array qilib beradi yani alpha = "abc" split("")dan keyin alpha = ["a", "b" , "c"] 
//task 1 input : "bed " , output:020504
// let elem = prompt()
// let alpha = "abcdefghjklmnopqrstuvxyz"
// let result = ""
// for (let item of elem.split("")) {
//   for (let letter of alpha.split("")) {
//     if (item == letter) {
//       let index = alpha.indexOf(item)
//       if (index <= 9) {
//         index = `0${index + 1}`
//       }
//       result += index
//     } else {
//       console.log("No letters found");
//     }
//   }
// }
// console.log(result);

//task 2
// video array methods