/*
Data type
  Number() 
  Infinity(masalan: 1 / 0)
  BigInt(2 ** 53)
  String()
  Boolean
  undefined, null, 
  Object()
  (only 8)
*/

// let x = 10;
// console.log(typeof x); //number
// typeof variableni turini aniqlash
// Math
// console.log(Math.PI); // 3.14
// console.log(Math.PI); // 3.14
// console.log(Math.PI); // 3.14
// console.log(Math.ceil(2.3)); // ceil yaxlitlash tepaga qarab
// console.log(Math.floor(2.3)); // floor yaxlitlash pastga qarab
// console.log(Math.round(2.5)); //  yaxlitlash
// ler randomNumber = Math.random() // 0 dan 1 gacha tasodifiy sonni qaytaradi float
// console.log(randomNumber);
// console.log(Math.random() * 5); // 0 dan 1 gacha tasodifiy sonni qaytaradi float
// console.log(Math.round(Math.random() * 1000)); // 0 dan 1 gacha tasodifiy sonni qaytaradi int
// console.log(Math.round(Math.random() * 5 + 10)); // 10 dan 15 gacha tasodifiy sonni

// arfimetik amallar
// console.log(2+2);//4
// console.log(10-2);//8
// console.log(10-2);//8
// console.log(10/2);//5
// console.log(10*2);//10
// console.log(10**2);//100

// console.log(2 * "apple"); // NaN Not a Number
// console.log("apple" + 2); // apple2

// let num = 5.3
// console.log(num.toFixed()); //toFixed = Math.round
// console.log(num.toString()); //toString = 5 = string

// let a = "15"
// console.log(182 - a); // NaN
// console.log(182 - Number(a)); // 167 strni intga aylantirib beryabdi

// let b= 12.5
// console.log(typeof String(b)); //intni strga aylantirib beradi



// let strnumber = `10`;
// console.log(typeof strnumber); //string

// let str1 = "Javascript"
// let str2 = "Javascript vs Pyton"
// let str3 = `${str1} vs c++` // ${} bu faqat `` ichida ishlaydi
// console.log(str1 + " " + str2 + " " + str3);

// let user = `John :\n\t*is_superuser=true\n\t*is_admin=true`
// console.log(user);

let str1 = "javascript"
console.log(str1.toLowerCase()); "kichik harfflar"
console.log(str1.toUpperCase()); "katta harfflar"
console.log(str1[0]);//j
console.log(str1[1]);//a
console.log(str1[2]);//v
console.log(str1[3]);//a
console.log(str1[4]);//s
console.log(str1[5]);//c
console.log(str1[6]);//r
console.log(str1[7]);//i
console.log(str1[8]);//p
console.log(str1[9]);//t
console.log(str1[0].toUpperCase() + str1[1] + str1[2] + str1[3] + str1[4].toUpperCase() + str1[5] + str1[6] + str1[7] + str1[8] + str1[9].toUpperCase());

console.log(str1.length); // 10 , lengt=len , type=int