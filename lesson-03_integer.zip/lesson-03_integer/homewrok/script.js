// alert("task 1")
// let l = +prompt("uzunlikni kirit");
// console.log(l/100 , "metr");

// alert("task 2")
// let k = +prompt("kilogramni kirit");
// console.log(k/1000 , "tonna");

// alert("task 3")
// let b = +prompt("necha baytligini kirit");
// console.log(Math.round(b));

// alert("task 4")
// let a = +prompt("1-sonni kirit");
// let b = +prompt("2-sonni kirit");
// console.log(a/b);

// alert("task 5")
// let a = +prompt("1-sonni kirit");
// let b = +prompt("2-sonni kirit");
// console.log(a / b , "marotaba joylashadi" , a % b , "qismi sig`may qoladi");

// alert("task 6")
// let a = +prompt("2 xonali son kirit");
// console.log("o`nlikalar xonasi =" ,  Math.floor((a%100) / 10) , "birliklar xonasi =", a%10);

// alert("task 7")
// let a = +prompt("2 xonali son kirit");
// console.log( Math.floor((a%100) / 10) + ( a%10));

// alert("task 8")
// let a = +prompt("2 xonali son kirit");
// let b = Math.floor((a % 100) / 10);
// let c = (a%10)
// console.log( c ,  b);

// alert("task 9")
// let a = +prompt("3 xonali son kirit");
// console.log("yuzliklar xonasidagi son=" , Math.floor(a/100));

// alert("task 10")
// let x = +prompt("3 xonali son kirit");
// console.log("birliklar xonasi =" , x % 10 , "o`nliklar xonasi =" , Math.floor((x%100)/10) );

// alert("task 11")
// let x = +prompt("3 xonali son kirit");
// console.log((Math.floor(x/100)) +(Math.floor((x%100)/10)) + (x%10) );

// alert("task 12")
// let x = +prompt("3 xonali son kirit");
// let x1 = (x % 10);
// let x2 = (Math.floor((x % 100) / 10));
// let x3 = (Math.floor(x / 100));
// console.log(x1 , x2 , x3 );

// alert("task 13")
// let x = +prompt("3 xonali son kirit");
// let x1 = (x % 10);
// let x2 = (Math.floor((x % 100) / 10));
// let x3 = (Math.floor(x / 100));
// console.log(x2 , x3 , x1 );

// homewrok
// alert("task 14")
// let x = +prompt("3 xonali son kirit");
// let x1 = (x % 10);
// let x2 = (Math.floor((x % 100) / 10));
// let x3 = (Math.floor(x / 100));
// console.log(x3 , x1 , x2);

// alert("task 15")
// let x = +prompt("3 xonali son kirit");
// let x1 = Math.floor(x % 10);
// let x2 = (Math.floor((x % 100) / 10));
// let x3 = (Math.floor(x / 100));
// console.log(x2 , x1 , x3);

// alert("task 16")
// let x = +prompt("3 xonali son kirit");
// let x1 = Math.floor(x % 10);
// let x2 = (Math.floor((x % 100) / 10));
// let x3 = (Math.floor(x / 100));
// console.log(x1 , x3, x2);

// alert("task 19")
// let n = +prompt("kun boshidan qancha sekund o'tganini kirit");
// let minut = Math.floor((n%3600)/60);
// console.log(minut , "minut vaqt o`tdi");

// alert("task 20")
// let n = +prompt("kun boshidan qancha sekund o'tganini kirit");
// let time = Math.floor(n/3600);
// console.log(time , "soat vaqt o`tdi");

// alert("task 21")
// let n = +prompt("kun boshidan qancha sekund o'tganini kirit");
// let minut = Math.floor((n%3600)/60);
// let sek = n % 60;
// console.log(minut , "minut" , sek , "sekund vaqt o`tdi")

// alert("task 22")
// let n = +prompt("kun boshidan qancha sekund o'tganini kirit");
// let time = Math.floor(n/3600);
// let sek = n % 60;
// console.log(time , "soat" , sek , "sekund vaqt o`tdi");

// alert("task 23")
// let n = +prompt("kun boshidan qancha sekund o'tganini kirit");
// let time = Math.floor(n/3600);
// let minut = Math.floor((n%3600)/60);
// let sek = n % 60;
// console.log(time , "soat" , minut , "minut" , sek , "sekund vaqt o`tdi");
