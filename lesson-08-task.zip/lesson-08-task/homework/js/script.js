// alert("Task 1")
// let k = 10;
// let n = 5;
// for (let i = 0, i < n ; i++) {
//   console.log(k);
// }

// alert ("Task 2")
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = a--; i < b; i++){
//   console.log(i);
// }

// alert ("Task 3")
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = b; i < a; i--){
//   console.log(i);
// }


// alert ("Task 4")
// let kg = +prompt("1 kgni narxini kiriting");
// for (let i = 0; i < 10; i = i + 0.1) {
//   console.log(Math.floor(i * kg));
// }

// alert ("Task 5")
// let cost = +prompt("1 kgni narxini kiriting");
// for (let i = 1; i < 10; i++) {
//   var kg = i / 10
//   console.log(Math.floor(cost * kg));
// }

// alert ("Task 6")
// let cost = +prompt("1 kgni narxini kiriting");
// for (let i = 0; i < 10; i = i++) {
//   var kg = i / 10
//   console.log(`${kg}kg konfent ${cost * kg}`);
// }

// alert("Task 7")
// let jami = 0
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = a; i < b; i++){
//   jami = jami + i 
//   console.log(jami);
// }

// alert("Task 8")
// let jami = 1
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = a; i < b; i++){
//   jami = jami * i 
//   console.log(jami);
// }

// alert("Task 9")
// let jami = 0
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = a; i < b; i++){  
//   jami = jami + i**2
//   console.log(jami);
// }

// alert("Task 10")
// let n = 10
// let s = 0
// for (n; n > 0; n--){
//   s +=(1/n)
// }

// alert("Task 15") //cola
// let n = +prompt("n ni kiriting");
// let a = +prompt("a ni kiriting");
// for (let i = 0; i < n; i++){
//   console.log(a*);
// }