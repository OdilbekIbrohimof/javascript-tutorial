// let str = prompt("so'z kiriting");
// let resualt = ""
// for (let i = 0; i < str.length; i++) {
//   if (i % 2 === 0) {
//     resualt += str[i].toUpperCase()
//   } else {
//     resualt += str[i].toLowerCase()
//   }
// }
// console.log(resualt);

//task 2
// let s = promt("son kiritning")
// let s = "2566451234867464148613"
// let count = 0
// for (let i = 0; i < s.length; i++){
//   if (s[i] == 6) {
//     count ++
//   }
// }
// console.log("bu raqamda 6 soni " , count , "marotaba qatnashagan");

// task 3
// let score1 = 0;
// let score2 = 0;
// for (let i = 0; i <  4; i++){
//   let p1ch1 = confirm("Player 1 Tasodifiy son kerakmi");
//   if (p1ch1 == true) {
//     score1 += Math.ceil(Math.random()*6)
//   }
//   let p2ch1 = confirm("Player 2 Tasodifiy son kerakmi");
//   if (p2ch1 == true) {
//     score2 += Math.ceil(Math.random()*6)
//   }
// }
// console.log(score1);
// console.log(score2);
// if (score1 > score2) {
//   console.log(score1 ," ball bilan Player 1 yutdi");
// }else if (score1 == score2) {
//   console.log("draw");
// }else {
//   console.log(score2 ," ball bilan Player 2 yutdi");
// }

//task 4
// let s = prompt("son kiritning")
// let resault = ""
// for (let i = 0; i < s.length; i++){
//   if (!resault.includes(s[i])) {
//     resault += s[i]
//   }
// }
// console.log(resault);

//task 5
// let s = prompt("son va belgilar kiritning");
// let resault = "";
// let num = "0 1 2 3 4 5 6 7 8 9 ";
// for (let i = 0; i < s.length; i++) {
//   if (num.includes(s[i])) {
//     resault += s[i]
//   }
// }
// console.log(resault); 