// var , let , const
// var x = 10;
// let y = 15;
// const pi = 3.14;
// var x = "apple"
// var a = "samsung"
// console.log(a + " company");
// let name = "Odilbek"
// let age = 15
// let language = "JavaScript"
// console.log("Ismi " + name + " yoshi " + age + " o\'rganayotgan dasturlash tili " + language + "biladigan tillari HTML5 , CSS3 , SCSS , SASS , BOOTSTRAP , PYTHON");

// let COLOR = "#fff"
// COLOR = "#000"
// console.log(COLOR); // dasturchilar tushinishi uchun constni o'rniga
// shu nomlar bilan o'zgaruvchi ohish mmkin emas
// var, let , cons, if, else, catch , try, function, break , while , for , class , return , script , contunnue ,
// prompt("ismini kirit") input

// confirm()
// if (confirm("ok or cancel")) {
//   alert("ok")
// } else {
//   alert(cancel)
// }

// task 1
// let a = +prompt("tomonini kiriting")
// console.log("perimetr = ", 4 * a);

// task 2
// let b = +prompt(" tomonini kirit")
// console.log("yuzasi teng", b ** 2);
// console.log("perimetr = ", 4 * b);

// task 3
// let a = +prompt("1-tomonini kirit")
// let b = +prompt("2-tomonini kirit")
// console.log("yuzasi" , a*b , "perimetri" , 2*(a+b));

// task 4
// let d = +prompt("diametrini kirit")
// console.log("uzunligi = " , 3.14*d);

// task 5
// let a = +prompt("kubning yon tomonini kirit")
// console.log("unung hajmi " , a**3 , "to\'la sirti" , 6*(a**2));

// task 6
// let a = +prompt("1-tomonini kirit")
// let b = +prompt("4-tomonini kirit")
// let c = +prompt("3-tomonini kirit")
