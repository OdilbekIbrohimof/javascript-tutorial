// alert("task 1")
// let a = +prompt("tomonini kiriting")
// console.log("perimetr = ", 4 * a);

// alert("task 2")
// let b = +prompt(" tomonini kirit")
// console.log("yuzasi teng", b ** 2);
// console.log("perimetr = ", 4 * b);

// alert("task 3")
// let a = +prompt("1-tomonini kirit")
// let b = +prompt("2-tomonini kirit")
// console.log("yuzasi" , a*b , "perimetri" , 2*(a+b));

// alert("task 4")
// let d = +prompt("diametrini kirit")
// console.log("uzunligi = " , 3.14*d);

// alert("task 5")
// let a = +prompt("kubning yon tomonini kirit")
// console.log("unung hajmi " , a**3 , "to\'la sirti" , 6*(a**2));

// alert("task 6")
// let a = +prompt("Paralepepedning 1-tomonini kirit")
// let b = +prompt("2-tomonini kirit")
// let c = +prompt("3-tomonini kirit")
// console.log("Paralepepedning hajmi" , a*b*c , "ga teng uning to'la sirti esa" ,2*( (a*b)+(b*c)+(a*c) ) , "ga teng" );

// alert("task 7")
// let r = +prompt("doirani radiusini kirit")
// let PI = 3.14
// console.log("doiraning uzunligi =" , 2*PI*r , "doiraning yuzasi =" , PI*(r**2));

// alert("task 8")
// let a = +prompt("1-sonni kirit")
// let b = +prompt("2-sonni kirit")
// console.log("siz kiritgan sonlarnig o'rta arfimetigi" , (a+b)/2 , "ga teng");

// alert("task 9")
// let a = +prompt("1-sonni kiriting")
// let b = +prompt("2-sonni kiriting")
// console.log("siz kiritgan sonlarnig o'rta geometrigi" ,(a*b)**0.5  , "ga teng");

// alert("task 10")
// let a = +prompt("1-sonni kiriting")
// let b = +prompt("2-sonni kiriting")
// console.log("yigindisi = " , a+b , "ko`patmasi =" , a*b , "1-sonning darajasi =" , a**2 , "ikkinchi sonni darajasi =" ,b**2);

// alert("task 11")
// let a = +prompt("1-sonni kiriting")
// let b = +prompt("2-sonni kiriting")
// console.log("yigindisi = " , a+b , "ko`patmasi =" , a*b , "1-sonning moduli =" , Math.abs(a) , "ikkinchi sonning moduli =" , Math.abs(b));

// alert("task 12") chola c ildiz
// let a = +prompt("1-tomonini kiriting")
// let b = +prompt("2-tomonini kiriting")
// let c = ((a**2) + (b**2))**0.5
// console.log("gipotenuzasi =" , c , "perimetri =" , a+b+c );

// alert("task 13")
// let r = +prompt("1-doirani radiusini kirit")
// let r2 = +prompt("2-doirani radiusini kirit")
// let PI = 3.14
// console.log("1-doiraning yuzasi =" , PI*r ,"2-doiraning yuzasi =" , PI*r2  , "ularnig ayrimasi =" , PI*(r*r2));

// task 16
// alert("task 16")
// let a = +prompt("1-sonni kirit")
// let b = +prompt("2-sonni kirit")
// console.log("2 nuqta orasidagi masofa =" , b-a);

// alert("task 17")
// let a = +prompt("A nuqtani kirit")
// let b = +prompt("B nuqtani kirit")
// let c = +prompt("C nuqtani kirit")
// console.log("A C nuqta orasidagi masofa =" , c-a ,"B C nuqta orasidagi masofa =" , c-b , "ikki kesma uzunligini yig'indisi =" , (c-a)+(c-b));

// alert("task 18")
// let a = +prompt("A nuqtani kirit")
// let c = +prompt("C nuqtani kirit")
// let b = +prompt("B nuqtani kirit")
// console.log("ikki kesma uzunligini yig'indisi =" , (c-a)*(b-c));

// alert("task 22")
// let a = +prompt("1-sonni kirit")
// let b = +prompt("2-sonni kirit")
// let c = a
// a = b
// b = c
// console.log("1-son =" , a , "2-son =" , b);

// 18
// alert("task 23")
// let a = +prompt("1-sonni kirit")
// let b = +prompt("2-sonni kirit")
// let c = +prompt("3-sonni kirit")
// let d = a
// let e = b
// let f = c
// a = e
// b = f
// c = d
// console.log("1-son =" , a , "2-son =" , b , "3-son =" , c);

// alert("task 24")
// let a = +prompt("1-sonni kirit")
// let b = +prompt("2-sonni kirit")
// let c = +prompt("3-sonni kirit")
// let d = a
// let e = b
// let f = c
// a = f
// b = d
// c = e
// console.log("1-son =" , a , "2-son =" , b , "3-son =" , c);

// alert("task 25   x ning qiymati kiritilganda 3x**6 - 6x**2 - 7 funksiyani bajaruvchi pragramma")
// let x = +prompt("X ni kirit")
// console.log("javob:" , (3*(x**6)) - (6*(x**2)) - 7 );

// alert("task 26 x ning qiymati kiritilganda 4(x-3)**6 - 7(x-3)**3 +2 funksiyani bajaruvchi pragramma")
// let x = +prompt("X ni kirit")
// console.log("javob:" , (4*(x-3)**6) - (7*(x-3)**3) +2  );

// alert("task 27 A ning qiymati kiritilganda a**2 , a**4 , a**8 funksiyani bajaruvchi pragramma")
// let a = +prompt("A ni kirit")
// console.log("a ning darajasi =" , a**2,"a ning 4-darajasi =" , a**4, "a ning 8-darajasi =" , a**8);

// alert("task 28 A ning qiymati kiritilganda a**2 , a**3 , a**5 , a**10, a**15 funksiyani bajaruvchi pragramma")
// let a = +prompt("A ni kirit")
// console.log("a ning darajasi =" , a**2,"a ning 3-darajasi =" , a**3, "a ning 5-darajasi =" , a**5 , "a ning 10-darajasi =" , a**10 , "a ning 15-darajasi =" , a**15);