let langs = document.querySelector(".change_pr_lang")
// addEventListener(envent nomi , event vaqti ishlaydigan funksiya)
langs.addEventListener("change", (event) => {
  console.log(event.target); // qaysi html element ustida shu hodisa bo'lganini chiqaradi
  console.log(event.target.value);
  document.querySelector("#pr_lang").innerHTML = event.target.value
});

// addEventListener - DOM da event -hodisalarni kuzatuvchi va ular vaqtida ko'rsatilgan funksiyalarni chiqaruvchi alohida funksiya

// Eventlar turlari:
//   1 - Window
//   2 - MouseEvent
//   3- KeyboardEvent

window.addEventListener("DOMContentLoaded", function (e) {
  console.log(e);
})

let modal = querySelector(".modal")

let count = 0
modal.addEventListener("mousemove", (e) => { //blockda harakatlansa
  // count++
  console.log(count);
})

modal.addEventListener("mouseover", (e) => { // blockga kirsa 
  // count++
  console.log(count);
})

modal.addEventListener("mouseleave", (e) => { // mouse ketsa
  // count++
  console.log(count);
})

let bx = document.querySelector(".bx")
modal.addEventListener("mouseover", (e) => {
  bx.style.positon = "absolute"
  bx.style.width = `${Math.round(Math.random() * 700)}px`
  bx.style.height = `${Math.round(Math.random() * 700)}px`
})

let btn =document.querySelector(".btn")
btn.addEventListener("mouseover", (e) => { 
  document.querySelector(".wrapper-2").classList.toggle("wrapper-2-up ")
})

function windowUp() {
  document.querySelector(".wrapper-2").classList.toggle("wrapper-2-up")
  document.querySelector(".wrapper-1").classList.toggle("wrapper-1-left")
}