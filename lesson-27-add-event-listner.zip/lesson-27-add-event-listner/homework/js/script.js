let btn =document.querySelector(".btn")
btn.addEventListener("mouseover", (e) => { 
  document.querySelector(".wrapper-2").classList.toggle("wrapper-2-up ")
})

function windowUp() {
  document.querySelector(".wrapper-2").classList.toggle("wrapper-2-up")
  document.querySelector(".wrapper-1").classList.toggle("wrapper-1-left")
}

function showAlert() {
  alert('Clicked!');
}