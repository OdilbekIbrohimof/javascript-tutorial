function openClose() {
  let sidebarMenu = document.querySelector(".sidebar-menu")
  sidebarMenu.classList.toggle("show")
}

function openAccardion() {
  let obj = document.querySelector(".accardion")
  obj.classList.toggle("down")
}

// window.onload = function () {
//   let equal = document.querySelector(".eq")
//   let col = document.querySelectorAll(".col")
//   setTimeout(() => {
//     for (let item of col) {
//       item.style.backgroundColor = "#232328"
//       item.style.height = `${Math.random() * 450}`
//       item.style.backgroundColor = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`
//     }
//   })
// }

// window.addEventListener("keypress", (event) =>) {
//   if (event.key == "e") {
//     eq()
//   } else if (event.key == "m") {
//     eq()
//   }
// }