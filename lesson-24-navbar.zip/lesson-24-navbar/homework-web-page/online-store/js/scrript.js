function showMenu() {
  document.querySelector(".menu").style.display = "block"
}

function closeMenu() {
  document.querySelector(".menu").style.display = "none"
}

function accardion(){
  let obj = document.querySelector(".admin-section-3")
  let obj2 = document.querySelector(".as-3")
  obj.classList.toggle("admin-section-3-down")
  obj2.classList.toggle("admin-section-3-down-div")
}

function headAnime1() {
  let header = document.querySelector("header")
  header.style.backgroundColor = "#FF6A00"
  document.querySelector(".heading-anime-01").style.color = "black"
  document.querySelector(".anime-img-1").style.display = "block"
  document.querySelector(".anime-img-2").style.display = "none"
  document.querySelector(".anime-img-3").style.display = "none"
  document.querySelector(".anime-img-4").style.display = "none"
  document.querySelector(".anime-img-5").style.display = "none"
}

function headAnime2() {
  let header = document.querySelector("header")
  header.style.backgroundColor = "#855FA8"
  document.querySelector(".heading-anime-02").style.color = "black"
  document.querySelector(".anime-img-1").style.display = "none"
  document.querySelector(".anime-img-2").style.display = "block"
  document.querySelector(".anime-img-3").style.display = "none"
  document.querySelector(".anime-img-4").style.display = "none"
  document.querySelector(".anime-img-5").style.display = "none"
}

function headAnime3() {
  let header = document.querySelector("header")
  header.style.backgroundColor = "#62BFC4"
  document.querySelector(".heading-anime-03").style.color = "black"
  document.querySelector(".anime-img-1").style.display = "none"
  document.querySelector(".anime-img-2").style.display = "none"
  document.querySelector(".anime-img-3").style.display = "block"
  document.querySelector(".anime-img-4").style.display = "none"
  document.querySelector(".anime-img-5").style.display = "none"
}

function headAnime4() {
  let header = document.querySelector("header")
  header.style.backgroundColor = "#AD2529"
  document.querySelector(".heading-anime-04").style.color = "black"
  document.querySelector(".anime-img-1").style.display = "none"
  document.querySelector(".anime-img-2").style.display = "none"
  document.querySelector(".anime-img-3").style.display = "none"
  document.querySelector(".anime-img-4").style.display = "block"
  document.querySelector(".anime-img-5").style.display = "none"
}

function headAnime5() {
  let header = document.querySelector("header")
  header.style.backgroundColor = "#6B6D73"
  document.querySelector(".heading-anime-05").style.color = "black"
  document.querySelector(".anime-img-1").style.display = "none"
  document.querySelector(".anime-img-2").style.display = "none"
  document.querySelector(".anime-img-3").style.display = "none"
  document.querySelector(".anime-img-4").style.display = "none"
  document.querySelector(".anime-img-5").style.display = "block"
}

function showCategory() {
  document.querySelector(".category").style.display = "block"
}

function closeCategory() {
  document.querySelector(".category").style.display = "none"
}