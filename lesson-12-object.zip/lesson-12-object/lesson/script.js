// Object  js uchun {} doim object

// let userName = "odilbek"
// let userAge = 15
// let password = "qwerty"

// //object variable user objectini atributi yani sifati
// let user = {
//   userName: "odilbek",
//   userAge: 15,
//   password: "qwerty",
//   changePassword : function (newPassword) { // method yani harakati
//     this.password = newPassword // methodni ichida turib userni atributini chaqirish uchun this ishlatiladi 
//   }
// }
// console.log(user.userName);
// user.changePassword("12345")
// console.log(user);

// let car = {
//   model: "Shevrolet",
//   price: "14000",
//   name: "Gentra",
//   color: "delfin",
//   drive: function () {
//     console.log(`${this.model + " " + this.name} is drive`);
//   }
// }
// car["color"] = "white" // color maydonini qiymatini o'zgratirish
// car.count = 23 // objectga yangi maydon qo'shish. car.count = 23 === car["count"] = 23
// console.dir(car) // objectni qanday bo'lsa shunday chiqaradi ,  objectga qulay
// car.drive()
// console.log(car.name);
// console.log(car.model);
// console.error("hello")

//task 1
// function robotMake(name, model, battery, year, programg, color) {
//   return {
//     name: name,
//     model: model,
//     battery: battery,
//     year: year,
//     programg: programg,
//     color: color,
//     method: function () {
//       console.log("robot gapirmoqda hamda yurmoqda");
//     }
//   }
// }

// console.log(robotMake("() d | |_ B E |<", "rt3", "60", 2022, "Arduino", "white"));

//task 2
// let user = {}
// user["name"] = "Jon"
// user["surname"] = "Smit"
// user["name"] = "Pet"
// delete user.name
// console.dir(user)

let obj = {
  name: "john",
  age: 23,
  country: "USA",
  address: "Texas ,LA",
  skills: {
    programmimg: "Javascript",
    sport: {
      case1: "Ping Pong",
      case2: "PS5",
      case3: "Futboll"
    }
  }
}

// for in , obyektlarni iteratsiya qilib beradi(takrorlab)
for (let key in obj) {
  console.log(obj[key]);
  if (typeof obj[key] == "object") {
    for (let i in obj[key]) {
      if (typeof obj[key] == "object") {
        for (let k in obj[key][i]) {
          console.log(obj[key][i][k]);
        }
      }
    }
  }
}
console.log(obj.skills.sport.case3);
console.log("age" in obj) ;

