// var , let, const


//   let x;

// x = 0

// String
// Number
// Boolean
// null
// undefined
// Object
// Infinity
// BigInt

// let s = ""
// let s = ''
// let x;
// let s = ${ x }
// console.log(s)

// let n = 1.1
// let n12 = -1.1

// console.log("1" + 1) //11
// console.log("1" / 1) //1
// console.log("2" * 2) //4

// console.log(10 > 5 && 2 > 3) // false
// console.log(10 > 15 || 2 > 3) //false
// console.log(!true) // false

// if (shart - 1) { harakat }
// else if (shart - 2) { harakat }
// else { harakat }
// let x = 10 > 20 ? "Ok" : "Error"
// console.log(x) // Error


// for (let i = 1; i <= 10; i++) {
//   console.log(i)
// }
// let i = 0
// while (true) {
//   i++
//   console.log(i)
//   if (i >= 10) {
//     break
//   } else {
//     continue
//   }
// }
// let i = 0
// do {
//   i++
//   console.log(i)

// } while (i >= 5)

// let arr = [true, "str", null, 1]
// console.log(typeof arr[arr.length / 1]) //undefined
// console.log(typeof arr[arr.length / 2]) //object
// console.log(typeof arr) // object
// console.log(arr[arr.length / 2])

// let obj = {
//   name: "John",
//   age: 25
// }
// console.log(obj.name)
// let x = 2
// console.log((x * 2) * obj.age) //100
// console.log((x * 2) * obj.age / 2 + 10 / Math.round(Math.random() * 3)) //
// let obj = {
//   name: "John",
//   age: 25
// }
// for (let k in obj) {
//   console.log(obj[k])
// }
// for (let i of arr) {
//   console.log(i)
// }
// let arr = [true, "str", null, 1, 0]
// arr.forEach((item) => {
//   if (item) {
//     console.log(item)
//   }
// })

// function main(x, y) {
//   if (x > 0 && y > 0) {
//     return x + y
//   }
// }
// let main = function (x, y) { return x + y }
// let arrowMain = (x, y) => { return x * y }

// function callBackF(state, f1, f2) {
//   if (state) {
//     return alert(f1(5, 5))
//   } else {
//     return alert(f2(5, 5))
//   }
// }
// callBackF("", main, arrowMain)


// task 1
// let num = prompt("qoldiqli son kiriting")
// alert(`${num[0] + num[1]}`)

// task 2
// let age = +prompt("yoshingizni kiriting")
// if (age > 10 && age < 18) {
//   alert("Ruxsat yo'q")
// } else if (age >= 18 && age <= 25) {
//   alert("Ruxsat bor")
// } else if (age >= 25 && age <= 50) {
//   alert("Boshqa safar")
// } else if (age > 50) {
//   alert("Yoshingiz katta")
// }

// task 3
// let num2 = +prompt("2 xonali son kiriting")
// if (num2 / 10 > Math.round(num2 % 10)) {
//   alert("chap taraf katta")
// } else {
//   alert("O'ng taraf katta")
// }