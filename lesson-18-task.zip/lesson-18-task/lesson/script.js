// alert("task 1")
// let userNum = +prompt("3 xonali son kiriting")
// let room1 = Math.floor(userNum % 10)
// let room2 = Math.floor((userNum % 100) / 10)
// let room3 = Math.floor(userNum / 100)
// if (room3 > room2 && room3 > room1 && room1 < room2) {
//   alert("true")
// } else {
//   alert("false")
// }

// alert("task 2")
// let userNum = prompt("4 xonali son kiriting")
// let userNumarr = userNum.split("")
// if (userNumarr[0] == userNumarr[3] && userNumarr[1] == userNumarr[2]) {
//   alert("true")
// } else {
//   alert("false")
// }

// alert("task3")
// let arr = []
// for (let i = 0; i < 3; i++){
//   let userNum = +prompt("son kiriting")
//   arr.push(userNum)
// }
// console.log(arr.sort((a, b) => b - a)[0], arr.sort((a, b) => b - a)[1], arr.sort((a, b) => b - a)[2],);

// alert("task 3")
// console.log(prompt("son kirititng").split("").sort((a, b) => b- a).join(""));

let n = prompt("son kiriting")
  for (let i = 0; i < n.length.split(""); i++) {
    let res = 0
    for (let j = 0; n.length.split(""); i++) {
      if (i == j) {
        res ++
      }
    }
  }
  if (res == 1) {
    alert("true")
  }
  else {
    alert("false")
  }
