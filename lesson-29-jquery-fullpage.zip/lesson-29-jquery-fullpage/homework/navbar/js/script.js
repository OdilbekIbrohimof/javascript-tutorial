let bar = document.querySelector(".bar").addEventListener("click", (event) => {
  document.querySelector(".menu").classList.toggle("show")
})