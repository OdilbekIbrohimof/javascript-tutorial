//theme: array methods
// delete arr[0] // arrayini insdexi orqali elementini o'chirish methodi
//arr.splice(index[,deletaCount , elem1 , elemn])
// let res = arr.splice(3, 2, "php", "pascal") // 3 - elementdan bohlab 2 ta elementi olib tashlab orniga php va pascalni qo'shib qoyadi
// console.log(arr.slice(2, .5)); // 2 indexdan boshlab 5 - indexdagi elemetgacha faqat  copy qilib oladi 
// console.log(a.concat(b)); // bu method ikkita arrayni qoshish uchun yani birlashtirish uchun
// .forEach // bu elemntni elementlarini olib beradi for qilib forEach ga function yoziladi only
// let arr = ["abdullo", "oybek", "muhammadqodir", "sarvar"]
// let res = arr.map(item => item.length) // map siz ko'rsatgan array elemti uchun qo'laydi va yangi array hosi qilib beradi
// res.sort() // arrayni elemtlarini saralash  sortga function yozsa ham bo'ladi
// res.sort((a, b) => a - b) // somnlarni o'sish bo'yisha saralash
// res.sort((a, b) => b - a) // somnlarni kamayishi bo'yisha saralash
// res.reverse() // arraynni elemtlarini teskarisiga aylantirish

// let arr = ["I", "go", "home"]
// console.log(arr[0]);
// console.log(arr[arr.length - 1]);
// delete arr[0] // arrayini insdexi orqali elementini o'chirish methodi
// console.log(arr);

// let arr =["python" , "cpp" , "javascript", "ruby" , ".net"]
// let res = arr.splice(1, 3) // ['cpp', javascript' , 'ruby']
// let res = arr.splice(3 , 2, "php" , "pascal") // 3 - elementdan bohlab 2 ta elementi olib tashlab orniga php va pascalni qo'shib qoyadi
// console.log(res);

// let nums = [1, 2, 3, 4, 5, 6, 7, 8]
// console.log(nums.splice(3,4)); 

// let arr =["python" , "cpp" , "javascript", "ruby" , ".net"]
// console.log(arr.slice(2, .5)); // 2 indexdan boshlab 5 - indexdagi elemetgacha faqat  copy qilib oladi 

// let a = [1, 2, 3]
// let b = [4, 5, 6]
// console.log(a.concat(b)); // bu method ikkita arrayni qoshish uchun yani birlashtirish uchun

// function plusTen(num) {
//   return num + 10
// }
// let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9]
// let result = []
// arr.forEach(function(elem) {
//   resualt.push(plusTen(elem))
// })
// console.log(result);

// let str = "assalomu alaykum"
// let count = 0
// str.split("").forEach(function (elem) {
//   if (elem == "a") {
//     count ++
//   }
// })
// console.log(count);

// let arr = ["abdullo", "oybek", "muhammadqodir", "sarvar"]
// let res = arr.map(item => item.length)
// res.sort()
// res.sort((a, b) => a - b) // somnlarni o'sish bo'yisha saralash
// res.sort((a, b) => b - a) // somnlarni kamayishi bo'yisha saralash
// console.log(res);
// res.reverse()
// console.log(res);

// alert("task 1")
// let arr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
// let resualt = []
// arr.forEach(function (elem) {
//   if (elem % 2 == 0) {
//     resualt.push(elem **2)
//   }
// })
// console.log(resualt);

// let res = arr.map(elem => elem ** 2)
// console.log(res);

// alert("task2")
// let arr = [[1, 5, 6], [5, 8, 1], [9, 7, 9], [1, 2, 8]]
// let newArray = []
// arr.sort(arr.forEach(function (elem) {
//   let count = 0
//   for (let num of elem) {
//     count += num
//   }
//   newArray.push(count) 
// }))
// console.log(newArray.sort((a, b) => b - a));

// alert("task 3")
// let arr = [1, 5, 6, 2, 4, 8, 5, 50, 52, 2, 59, 56, 60]
// let res = arr.map(elem => { if (elem < 50) return elem })
// console.log(res.sort(n => {if (n) {return n}})); 