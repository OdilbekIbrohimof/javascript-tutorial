//function -  alohida nom bilan ajratilgan kod bo'lagi , kodnni istalgan joyida istalgan marotaba ishlatsa boladi
/*
Function turleri
1 - function declaration >> elon qilingan function
2- function experession >> ifoda function
3 - arrow function >> strelka function
4 - calback function >> biror bir functionni natija qilib qaytaradigan function

//1 - function declaration 
function funksiyaNomi(parametrlar) {
  function body
  return qaytarishi kerak bo'lgan natija
}

function plus(number1 , number2) {
  alert(number1 + number2)
}

plus(10 , 5)
*/

// function showMessage() {
//   console.log("hello");
// }

// function plus(number1 , number2) {
//   alert(number1 + number2)
// }

// plus(10 , 5)

// function plus(x, y) {
//   return x +y // only natijani qaytarish
// }

// console.log(plus(5 ,5));

// task 1

// function minus(x, y) {
//   return x - y 
// }
// console.log(minus(10, 5));

// function kop(x, y) {
//   return x * y
// }
// console.log(kop(10, 5));

// function division(x, y) {
//   if (x < b) {
//     return " a soni kichik"
//   } else {
//     return x / y
//   }
// }
// console.log(division(2, 5));

// function searchLetter(text) {
//   let count = 0;
//   for (let i = 0; i < text.length; i++) {
//     if (text[i].toLowerCase() == "a") {
//       count++
//     }
//   }
//   return `A harfi ${count} marta ishtirok etgan`
// }

// console.log(searchLetter("Assalomu alaykum"));

// function searchLetter(text) {
//   let count = 0;
//   let vowels = "aiuoe"
//   for (let i = 0; i < text.length; i++) {
//     if (vowels.includes(text[i].toLowerCase())) {
//       count++
//     }
//   }
//   return `unli harflar ${count} marta ishtirok etgan`
// }

// console.log(searchLetter("Assalomu alaykum"));

function Letter(a, text) {
  let count = "";
  for (let i = 0; i < a; i++) {
    count +=text + " "
  }
  return count
}

console.log(Letter(5 , "odilbek"));