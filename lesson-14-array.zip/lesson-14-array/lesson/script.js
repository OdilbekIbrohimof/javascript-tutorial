// array masiv.  , dan keyin berilgan variablelar yonma yon katakchada joylashadi
// let fruits = ["apple", "chery", "limon"]
// let arr ["str", true, 1, undefined]

//bunaqa usuli ham mavjud lekin kam ishlatiladi
// console.log(arr);
// console.log(arr_2);

// let arr = [1, 2, 3, 4, 5]
// arr[0] = "bir" // elementni index orqali o'zgartirish
// console.log(arr.length); // 5 number
// console.log(arr[0]);
// console.log(arr[1]);

// for (let i = 0; i < arr.length; i++) {
//   console.log(arr[i]);
// }
// tepadagi bilan bir xil ish bajaradi
// for (let element of arr) {
//   console.log(element);
// }
// let arr = [1, 2, 3, [-1, -2, -3], { name: "Array", len: 6 }]
// console.log(arr[arr.length - 1]); // oxirgi elementni consolga chiqarish
// console.log(arr[4].len);
// arr.push("array") // arrayni oxiriga element qo'shish
// arr.pop() // arr oxiridan bitta o'chirirsh
// arr.unshift("arr") // arr boshiga element qo'shish 
// arr.shift() // arr boshidan element o'chirirsh
// console.log(arr);

// let arr = []
// arr.unshift("first index")
// console.log(arr);
// arr.push("last index")
// console.log(arr);
// arr.shift()
// console.log(arr);
// arr.pop()
// console.log(arr);

// let matrix = [
//   [1, 2, 3],
//   [4, 5, 6],
//   [7, 8, 9]
// ]
// alert(matrix[1][1])

//task 1
// let arr = [1, 8, 3, 7, 2, 6, 1]
// for (let element of arr) {
//   if (element % 2 == 0) {
//     console.log(element ** 2);
//   }
// }

//task 2
// let arr = [Math.round(Math.random() * 10), Math.round(Math.random() * 20), Math.round(Math.random() * 30), Math.round(Math.random() * 40), Math.round(Math.random() * 50), Math.round(Math.random() * 60), Math.round(Math.random() * 70), Math.round(Math.random() * 80), Math.round(Math.random() * 90), Math.round(Math.random() * 10)]
// console.log(arr);

//taask 3
// let arr = [3, 2, 3, 3, 3, 3]
// let box = 0
// for (let i = 0; i < arr.length; i++) {
//   for (let j = 0; j < arr.length; j++) {
//     if (arr[i] > arr[j]) {
//       box += arr[i]
//       break
//     }
//   }
// }
// console.log(box);

//task 4
function num() {
  let arr = [Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000), Math.round(Math.random() * 1000),]
  console.log(arr);
  for (let i = 0; i < arr.length; i++) {
    if (element > 0 && i < 99) {
      console.log(`${i ** 2}`);
    }else if (i => 99 && i <= 399) {
      console.log(`${i ** 3}`);
    } else {
      console.log(`${i}`);
    }
  }
}
console.log(num());

//task 5 homework func 3ta arg input qiladi
// function main(count, toq, minus) {
//   let arr = []
// }
// console.log(main(5 , 2 , 1));
