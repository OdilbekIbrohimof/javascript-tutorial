// alert("task 1")
// let n = +prompt("nachta sonli massiv kerak")
// let arr = []
// for (let i = 0; i < n; i++){
//   arr.push(Math.round(Math.random()*10))
// }
// alert(arr);

// alert("task 2")
// let n = +prompt("nachta sonli massiv kerak")
// let arr = []
// for (let i = 0; i < n; i++) {
//   arr.push(2**i)
// }
// alert(arr);


// alert("task 7")
// let arr = [0, 1, 2, 3, 4, 5, 6]
// for (let i = arr.length; i == 0; i--) {
//   arr.pop(arr[i])
//   arr.unshift(arr[i])
// }
// alert(arr);

// alert("task 8")
// let arr = [1, 3, 8, 10, 13]
// let count = 0
// for (let i = 0; i < arr.length; i++) {
//   if (!arr[i] % 2 == 0) {
//     count += i
//   }
// }
// alert(`bu arrayda ${count} ta toq son mavjud`);

// alert("task 9")
// let arr = [1, 3, 8, 10, 13]
// let count = 0
// for (let i = 0; i < arr.length; i++) {
//   if (arr[i] % 2 == 0) {
//     count += i
//   }
// }
// alert(`bu arrayda ${count} ta juft son mavjud`);



