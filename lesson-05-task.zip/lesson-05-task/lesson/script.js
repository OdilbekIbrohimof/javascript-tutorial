// task 1

// let man = +prompt("kishi sonini kiriting")
// let gusht = (750 / 10) * man;
// let guruch = (1000 / 10) * man;
// let dumba = (250 / 10) * man;
// let sabzi = (1000 / 10) * man;
// let gushtgn = 50000 / 750;
// let guruchgn = 25000 / 1000;
// let dumbagn = 20000 / 250;
// let sabzign = 5000 / 1000;
// let jamiNarx = (guruch * guruchgn) + (gusht * gushtgn) + (dumba * dumbagn) + (sabzi * sabzign) ;
// console.log("sizga ", gusht, "gram go`sht , ", guruch, " gram guruch ,", dumba, "gram dumba va", sabzi, "gram sabzi kerak bo`ladi . Bular uchun", Math.round(jamiNarx), "ming so`m xarajat qilishingiz kerak bo`ladi");

// let money = +prompt("nech pulingiz borligini kiriting");
// let guruch = 1000 / 10;
// let gusht = 750 / 10;
// let dumba = 250 / 10;
// let sabzi = 1000 / 10;
// let gushtgn = 50000 / 750;
// let guruchgn = 25000 / 1000;
// let dumbagn = 20000 / 250;
// let sabzign = 5000 / 1000;
// let man = (guruch * guruchgn) + (gusht * gushtgn) + (dumba * dumbagn) + (sabzi * sabzign);
// console.log(Math.floor(money / man));

// task 2
// let time = 2014 - 1960;
// let oneYear = 8305 / time;
// console.log("orol dengizi yiliga " , oneYear , "kv2 ga kamaygan");

// task 3
// let gramm = +prompt("vazningizni garamda kiriting ");
// let ml = gramm * 35;
// console.log("siz bir kuniga " , ml , "ml litr suv ichishingiz kerak");

// task 4
// let num = +prompt("son kiriting");
// if ((num / 2) == 0)
//   alert("siz kiritgan son juft son");
// if ((num / 2) != 0)
//   alert("siz kiritgan son toq son");

// task 5
// let ism = "odilbek"
// console.log(ism[0] +"\n"  + ism[1]  +"\n" + ism[2]  +"\n" + ism[3]  +"\n" + ism[4]  +"\n" + ism[5] +"\n" + ism[6]);

// task 6
// let password = 6614
// let inputPassword = +prompt("parolni kiriting")
// if (inputPassword == password) 
//   console.log("parolni topdingiz");
// if (inputPassword > password) 
//   console.log("katta son kiritdingiz");
// if (inputPassword < password) 
//   console.log("kichik son kiritdingiz");