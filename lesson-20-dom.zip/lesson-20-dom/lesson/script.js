// console.log(document); // html hujjat obyekti
// console.log(window); // brauzer oyna obyekti
// let html = document
// console.log(html.body.tagName); //BODY tegni nomini chiqarish
// html.body.className = "red" //tegga class nomini berish
// console.log(html.body);

//Elementni qidirish va olish

// let a = document.getElementsByTagName("a")
// console.log(a); // htmlCollection nechta shu tag dan bolsa topib array qilib qaytaradi
// let cherry = document.getElementById("cherry")
// let orange = document.getElementsByClassName("orange") // class bo'yicha olish (array)

// for (let item of document.getElementsByTagName("li")) {
//   console.log(item.innerText);
// }

// let p = document.getElementById("text")
// p.innerText = "o'zimni shaxsiy matnim" // #text ni matnini o'zgartirish
// console.log(p);

//optiaml tag topuvchi funksiya 
// let ul = document.querySelector("ul") // css selectori bo'yicha elementni topish
// let li = document.querySelectorAll("li") // css selectori bo'yicha elementlarni topish
// console.log(ul);
// console.log(li);

// let orange = document.querySelector(".orange") // querySelector yordamida class bilan topish
// console.log(orange);

//name atributi bo'yicha olish asosan inputlarda ishlatiladi
// let elements = document.getElementsByName("language")
// console.log(elements.length); // 3
// console.log(elements[0]);
// console.log(elements[2]);

// let list = document.querySelector(".list") // ul
// console.log(list.parentElement); // ota elementini qaytaradi 
// console.log(list.children); // bola elementini qaytaradi 

//modal ni yo'qotish
// function closeModal() {
//   let btn = document.querySelector(".close")
//   btn.parentElement.style.display = "none"
// }