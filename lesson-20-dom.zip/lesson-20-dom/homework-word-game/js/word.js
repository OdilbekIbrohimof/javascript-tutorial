let wordList = [
  {
    word: "python",
    hint: "programming language"
  },
  {
    word: "gold",
    hint: "a yellow precious metal"
  },
  {
    word: "coding",
    hint: "related to programming"
  },
  {
    word: "bugs",
    hint: "related to programming"
  },
  {
    word: "rain",
    hint: "related to a water"
  },
]