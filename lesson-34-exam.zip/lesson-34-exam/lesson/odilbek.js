// task 1
// let s = prompt("30 gacha bo'lgan son kiriting")
// let newArr = []
// for (let i = 0; i < s; i++) {
//   if (i % 2 == 0) {
//     newArr.push(`${i}  `)
//   }
//   else {
//     newArr.push(`${i} `)
//   }
// }
// alert(newArr)

// task 2
// let chair = prompt("o'rindiq seriya raqamini kiriting")
// if (chair[0] == "a") {
//   alert("1- qator")
// } else if (chair[0] == "b") {
//   alert("2- qator")
// } else if (chair[0] == "c") {
//   alert("3- qator")
// } else if (chair[0] == "d") {
//   alert("4- qator")
// } else if (chair[0] == "e") {
//   alert("5- qator")
// } else if (chair[0] == "f") {
//   alert("6- qator")
// } else if (chair[0] == "g") {
//   alert("7- qator")
// } else if (chair[0] == "i") {
//   alert("8- qator")
// }

// task 3
// let kvartiraNumber = +prompt("kvartira raqamini kiritning")
// if (kvartiraNumber >= 1 && kvartiraNumber <= 4) {
//   alert("siz kiritgan kvartira raqami 1- qavatda joylashgan")
// } else if (kvartiraNumber >= 5 && kvartiraNumber <= 8) {
//   alert("siz kiritgan kvartira raqami 2- qavatda joylashgan")
// } else if (kvartiraNumber >= 9 && kvartiraNumber <= 12) {
//   alert("siz kiritgan kvartira raqami 3- qavatda joylashgan")
// } else if (kvartiraNumber >= 13 && kvartiraNumber <= 16) {
//   alert("siz kiritgan kvartira raqami 4- qavatda joylashgan")
// } else if (kvartiraNumber >= 17 && kvartiraNumber <= 20) {
//   alert("siz kiritgan kvartira raqami 5- qavatda joylashgan")
// } else {
//   alert("bu domda bu songa teng kvartira mavjud emas")
// }

// task 4
// let kvartiraNumber = +prompt("kvartira raqamini kiritning")
// if (kvartiraNumber >= 1 && kvartiraNumber <= 6) {
//   alert("siz kiritgan kvartira raqami 1- qavatda joylashgan")
// } else if (kvartiraNumber >= 7 && kvartiraNumber <= 12) {
//   alert("siz kiritgan kvartira raqami 2- qavatda joylashgan")
// } else if (kvartiraNumber >= 13 && kvartiraNumber <= 18) {
//   alert("siz kiritgan kvartira raqami 3- qavatda joylashgan")
// } else if (kvartiraNumber >= 19 && kvartiraNumber <= 24) {
//   alert("siz kiritgan kvartira raqami 4- qavatda joylashgan")
// } else if (kvartiraNumber >= 25 && kvartiraNumber <= 30) {
//   alert("siz kiritgan kvartira raqami 5- qavatda joylashgan")
// } else if (kvartiraNumber >= 31 && kvartiraNumber <= 36) {
//   alert("siz kiritgan kvartira raqami 6- qavatda joylashgan")
// } else if (kvartiraNumber >= 37 && kvartiraNumber <= 42) {
//   alert("siz kiritgan kvartira raqami 7- qavatda joylashgan")
// } else if (kvartiraNumber >= 43 && kvartiraNumber <= 48) {
//   alert("siz kiritgan kvartira raqami 8- qavatda joylashgan")
// } else if (kvartiraNumber >= 49 && kvartiraNumber <= 54) {
//   alert("siz kiritgan kvartira raqami 9- qavatda joylashgan")
// }


// task 5
// let a = +prompt("fortochkaning  a tomonini kiritng")
// let b = +prompt("fortochkaning  b tomonini kiritng")
// let d = +prompt("boshingizning  diametirini kiritng")
// if ((a > d && (a - d) >= 1) && (b > d && (b - d) >= 1)) {
//   alert("boshingiz fortochkaga sig'adi")
// } else {
//   alert("boshingiz fortochkaga sig'mayadi")
// }


// task 7
// let first = +prompt("son kiritinig")
// let second = +prompt("son kiritinig")
// let third = +prompt("son kiritinig")
// if (first > second && first > third) {
//   console.log("birinchi raqam eng katta son");
// } else if (first < second && first < third) {
//   console.log("birinchi raqam eng kichik son");
// } else {
//   console.log("birinchi raqam o'rta qiymatga ega");
// }
// if (second > first && second > third) {
//   console.log("ikkinchi raqam eng katta son");
// } else if (second < first && second < third) {
//   console.log("ikkinchi raqam eng kichik son");
// } else {
//   console.log("ikkinchi raqam o'rta qiymatga ega");
// }
// if (third > first && third > second) {
//   console.log("uchinchi raqam eng katta son");
// } else if (third < first && third < second) {
//   console.log("uchinchi raqam eng kichik son");
// } else {
//   console.log("uchinchi raqam o'rta qiymatga ega");
// }

// task 8
// let money = +prompt("Deposit")
// let lifetime = +prompt("Lifetime")
// let b = (money * 2) / 100
// let c = (money * 2.5) / 100
// let f = (money * 3.5) / 100
// if (lifetime <= 12) {
//   alert(`${money+ (b*lifetime)} so'm ${lifetime} oy`)
// } else if(lifetime <= 36) {
//   alert(`${money + (c * lifetime)} so'm ${lifetime} oy`)
// } else if (lifetime <= 60) {
//   alert(`${money + (d * lifetime)} so'm ${lifetime} oy`)
// } else if (lifetime > 60) {
//   alert(`${money + (f * lifetime)} so'm ${lifetime} oy`)
// }

// task 9
// task 9 , 1-shart
// let userNum = prompt("son kiriting")
// let userNumSplit = userNum.split("")
// let arrUserNum = []
// for (let i = 0; i < userNum.length; i++) {
//   arrUserNum.push(userNumSplit[userNumSplit.length - 1])
//   userNumSplit.pop(userNumSplit[userNumSplit.length - 1])
// }
// alert(arrUserNum)
// tas 9 , 2-shart
// arrUserNum = userNum.split("")
// arrUserNum.unshift(2)
// arrUserNum.push(2)
// alert(arrUserNum)
// task 9 ,3 - shart
// arrUserNum = userNum.split("")
// arrUserNum[arrUserNum.length-2] = "."
// alert(arrUserNum)

// task 10
// let ochko = +prompt("ochkoni kiriting")
// let win = 0
// let lose = 0
// let friend = 0
// let i =0
// while (i < ochko) {
//   i++
//   let num = Math.round(Math.random() * 3)
//   if (num == 2) {
//     let num = Math.round(Math.random() * 3)
//     if (num == 0) {
//       lose += 1
//     } if (num == 1) {
//       friend += 1
//     }
//     if (num == 3) {
//       win += 1
//     }
//   }
//   if (num == 0) {
//     lose += 1
//   } if (num == 1) {
//     friend += 1
//   }
//   if (num == 3) {
//     win += 1
//   }
//   ochko -= num
// }
// console.log(win, "ta yutuq");
// console.log(friend, "ta durrang");
// console.log(lose, "ta mag'lubiyat");