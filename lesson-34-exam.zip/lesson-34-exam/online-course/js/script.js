let img = document.querySelector(".section-6-img")
img.addEventListener("mouseover", (e) => {
  document.querySelector(".social").classList.toggle("social-block")
})

function eventsGrid() {
  documant.querySelector(".wrapper-container").classList.toggle("wrapper-conatiner-flex")
  document.querySelector(".wrapper-list").classList.toggle("wrapper-grid")
}