/*
// STRING METHODS
str.toUpperCase
str.toLocaleLowerCase
str.length
str.includes("")
str.indexOf("harffni indexsi")
str.startsWith("py") // bilan boshlanyaptimi
str.endsWith("on") // bilan tugayaptimi
"a".charCodeAt() // assci kodini chiqaradi

let str = "python";
console.log(str.toLocaleLowerCase);
console.log(str.toLocalUpperCase);
console.log(str.indexOf("h")); // h ni razryadini sorash
console.log("Python is OOP language".indexOf("OOP"));
console.log(str.includes("hon")); // strni ichida hon jumlasi bormi agar bor bo'lsa true bo'lmasa false 
console.log(str.includes("ava"));

console.log("a".charCodeAt());
console.log("A".charCodeAt());
*/

/* 
// SHARTNINI TEKSHIRISH AMMALRI . Bularni barchasi booleanda qiymat qaytaradi yani true or false
// >   : katta
// <   : kichik 
// >=  : katta yoki teng
// <=  : kichik yoki teng 
// ==  : teng
// !=  : teng emas 
// === : qatiy teng
// !== : qatiy teng emas
// !   : emas (inkor)

console.log(10 > 5); // true
console.log(7 < 9); // true
console.log(5 >= 5); // true
console.log(5 <= 0); // false
console.log("a" == "A"); // false
console.log("a" == "a"); // true
console.log("a" == "a"); // true
console.log("1" === 1); // false , === polniy tekshiradi hatoki typigacha
console.log("a" != "A"); // true
console.log(!true); // false , not true
console.log(!false); // true , not false
*/

/*
// MANTIQIY AMMALAR 
// and , or , not 
// and  = va  , 1 , 1 =1
// or  = yoki  , 0 , 1 =1
// && - and 
// || - or 
// ! - not 

let age = +prompt("Age ? \n")
console.log(age > 18);
console.log(age < 65);
console.log(age > 18 && age < 65); // agar 18dan katta va 65 dan kichik bo'lsa turue aks holda false
console.log(age > 18 || age < 65); // agar 18dan katta yoki 65 dan kichik bo'lsa turue aks holda false

console.log(Boolean("text")); // true
console.log(Boolean(" ")); // true
console.log(Boolean("")); // false
console.log(Boolean(0)); // false
console.log(Boolean(-56)); // true
*/

// let points = +prompt("imtixondan qancha ball olganingzi kiriting")
// let result = points > 60 ? "o'tdi" : "O'tmadi" // ? true bo'lsa , : else
// console.log("Imtihon natijasi" , result); 

/*
// if , else if ,  else
// if (shart > < == === !== ) {amal true bo'lganda}
// if (shart > < == === !== ) {amal true bo'lganda}else if (shart){amal} else{amal}
// if >> agar shart = true amal bajariladi
// else if >> agar shart = true amal bajariladi
// else amal bajariladi

let age = +prompt("Age")
if (age > 18) {
  console.log("welcome");
} if (age == 18) {
  console.log("welcome");
}else {
  console.log("you can't enter because your age is < 18");
}
*/

// task 1
// let num = +prompt("son kiriting");
// if (num == 1) {
//   alert("Windows")
// } else if (num == 2) {
//   alert("Linux")
// } else if (num == 3) {
//   alert("MacOs")
// } else {
//   alert("Bunday OS yo'q")
// }

// task 2
// let num = +prompt("son kiriting");
// if (num >= 1 && num <= 3) {
//   alert("Microsoft");
// } else if (num >=4 && num <= 6) {
//   alert("ubuntu");
// } else if (num >=7 && num <= 9) {
//   alert("Apple");
// } else {
//   alert("Son yo'q")
// }

// task 3 
// let age = +prompt("yoshingizni kiriting");
// let userName = prompt("UserNameingzni kiriting");
// if (age > 18 && userName.length >= 8) {
//   alert("O'tdingiz")
// } else {
//   alert("O'tmadingiz")
// }

// task 4 
let age = +prompt("yoshingizni kiriting");
let userName = prompt("UserNameingzni kiriting");
let emaiil = promt("Emailingizni kiriting");
if (age > 18 && userName.length >= 8 && emaiil.includes("@")) {
  alert("O'tdingiz")
} else {
  alert("O'tmadingiz")
}