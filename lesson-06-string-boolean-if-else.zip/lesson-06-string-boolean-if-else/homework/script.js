// alert("Task 1")
// let num = +prompt("son kiriting:")
// if (num > 0) {
//   alert(num+1)
// } else {
//   alert(num)
// }

// alert("Task 2")
// let num = +prompt("son kiriting:")
// if (num > 0) {
//   alert(num+1)
// } else {
//   alert(num -2)
// }

// alert("Task 3")
// let num = +prompt("son kiriting:")
// if (num > 0) {
//   alert(num+1)
// }else if (num == 0) {
//   alert(10)
// } else {
//   alert(num -2)
// }

// alert("Task 4")
// let musbats = 0
// let num1 = +prompt("1-son kiriting:")
// let num2 = +prompt("2-son kiriting:")
// let num3 = +prompt("3-son kiriting:")
// if (num1 > 0) {
//   musbats = musbats +1
// } 
// if (num2 > 0) {
//   musbats = musbats +1
// }
// if (num3 > 0) {
//   musbats = musbats +1
// }
// console.log("siz kiritgan sonlarning " ,musbats , "tasi musbat sonlar" )

// alert("Task 5")
// let musbats = 0
// let manfiy = 0
// let num1 = +prompt("1-son kiriting:")
// let num2 = +prompt("2-son kiriting:")
// let num3 = +prompt("3-son kiriting:")
// if (num1 > 0) {
//   musbats = musbats +1
// } else {
//   manfiy = manfiy + 1
// }
// if (num2 > 0) {
//   musbats = musbats +1
// }else {
//   manfiy = manfiy + 1
// }
// if (num3 > 0) {
//   musbats = musbats +1
// }else {
//   manfiy = manfiy + 1
// }
// console.log("siz kiritgan sonlarning " ,musbats , "tasi musbat va " , manfiy , "tasi manfiy sonlar" )

// alert("Task 6")
// let num1 = +prompt("1-son kiriting:")
// let num2 = +prompt("2-son kiriting:")
// if (num1 > num2) {
//   alert("siz kiritgan sonlarning birinchisi katta")
// } else {
//   alert("siz kiritgan sonlarning ikkinchisi katta")
// }

// alert("Task 7") // chola
// let num1 = +prompt("1-son kiriting:")
// let num2 = +prompt("2-son kiriting:")
// if (num1 < num2) {
//   alert("siz kiritgan sonlarning birinchisi kichik")
// } else {
//   alert("siz kiritgan sonlarning ikkinchisi kichik")
// }

// alert("Task 8")
// let num1 = +prompt("1-son kiriting:")
// let num2 = +prompt("2-son kiriting:")
// if (num1 > num2) {
//   console.log("kattasi " , num1 , "kichki" , num2)
// } else {
//   console.log("kattasi " , num2 , "kichki" , num1)
// }

// alert("Task 9")
// let num1 = +prompt("Ani kiriting:")
// let num2 = +prompt("Bni kiriting:")
// if (num1 > num2) {
//   console.log("A son =" , num2 - 1 , "B son =" , num2)
// } else {
//   console.log("A son =" , num1 , "B son =" , num2)
// }

// alert("Task 10")
// let num1 = +prompt("1 - sonni kiriting:")
// let num2 = +prompt("2-sonni kiriting:")
// if (num1 == num2) {
//   console.log(num1 + num2)
// } else {
//   console.log(0)
// }

// alert("Task 11")
// let num1 = +prompt("1 - sonni kiriting:")
// let num2 = +prompt("2-sonni kiriting:")
// if (num1 == num2) {
//   console.log(0)
// } else if(num1 > num2) {
//   console.log(num1)
// }else {
//   console.log(num2);
// }

// alert("Task 12")
// let num1 = +prompt("1 - sonni kiriting:")
// let num2 = +prompt("2-sonni kiriting:")
// let num3 = +prompt("3-sonni kiriting:")
// if (num1 < num2 && num1 < num3) {
//   console.log(num1)
// } else if(num2 < num1 && num2 < num3) {
//   console.log(num2)
// }else {
//   console.log(num3);
// }

// alert("Task 13")
// let num1 = +prompt("1 - sonni kiriting:")
// let num2 = +prompt("2-sonni kiriting:")
// let num3 = +prompt("3-sonni kiriting:")
// if (((num1 > num2 && num1 < num3) || (num1 > num3 && num1 < num2))) {
//   console.log(num1)
// } else if (((num2 > num1 && num2 < num3) || (num2 > num3 && num2 < num1))) {
//   console.log(num2)
// }else {
//   console.log(num3);
// }

// alert("Task 14")
// let num1 = +prompt("1 - sonni kiriting:")
// let num2 = +prompt("2-sonni kiriting:")
// let num3 = +prompt("3-sonni kiriting:")
// let big = 0
// let small = 0
// if (num1 > num2 && num1 > num3) {
//   big = num1
// } 
// if (num1 > num1 && num1 > num3) {
//   big = num2
// }
// if (num3 > num2 && num3 > num1) {
//   big = num3
// }
// if (num1 < num2 && num1 < num3) {
//   small = num1
// }
// if (num2 < num1 && num2 < num3) {
//   small = 2
// }
// if (num3 < num1 && num3 < num2) {
//   small = 3
// }
// console.log("kicki" , small , "kattasi " , big);

// alert("Task 15")
// let num1 = +prompt("1 - sonni kiriting:")
// let num2 = +prompt("2-sonni kiriting:")
// let num3 = +prompt("3-sonni kiriting:")
// let big = 0
// let small = 0
// if (((num1 + num2) > (num2 + num3)) || ((num1 + num2) > (num1 + num3))) {
//   console.log(num1 , num2);
// }else if (((num1 + num3) > (num2 + num1)) || ((num1 + num3) > (num2 + num3))) {
//   console.log(num1 , num3);
// }else if (((num2 + num3) > (num2 + num1)) || ((num2 + num3) > (num2 + num3))) {
//   console.log(num2 , num3);
// }else if (((num1 + num2) > (num2 + num3)) || ((num1 + num2) > (num2 + num3))) {
//   console.log(num1 , num2);
// }else if (((num3 + num2) > (num3 + num1)) || ((num3 + num2) > (num2 + num1))) {
//   console.log(num1 , num3);
// }else if (((num3 + num1) > (num3 + num1)) || ((num3 + num1) > (num2 + num3))) {
//   console.log(num1 , num3);
// }

// alert("Task 29")
// let num = +prompt("son kiriting")
// if ((num > 0) && (Math.floor(num % 2) == 0) ) {
//   alert("musbat juft son")
// } else if ((num > 0) && (Math.floor(num % 2) != 0) ) {
//   alert("musbat toq son")
// }else if ((num < 0) && (Math.floor(num % 2) == 0) ) {
//   alert("manfiy juft son")
// } else if ((num < 0) && (Math.floor(num % 2) != 0) ) {
//   alert("manfiy toq son")
// } else if (num == 0) {
//   alert("nolga teng")
// }