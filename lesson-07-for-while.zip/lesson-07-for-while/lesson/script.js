/*
// ternarny operator
let weight = +prompt("vaznini kirit");
let check = weight > 0 ? weight * 0.03 : alert("bratishka to'g'ri son kirit");
console.log(Math.round(check) + "litr");
*/

//FOR WHILE

// while
// let n = 7;
// while (true) {
//   let user = +prompt("sonni kirit");
//   if (user == n) {
//     console.log("togri");
//     break
//   }
//   else {
//     console.log("Notogri");
//   }
// }

// let n = +prompt("sizga nechigacha son kerak")
// let i = 0
// while (n > i) {
//   i++
//   console.log(i);
// }

// do while
// do {
//   i++
//   console.log(n > i);
// }while (n > i) {
  
// }

// FOR
// i , k , j , x
// for (let i = 0; i < 10; i++) {
//   console.log(i);
// }

// alert("Task 1")
// let k = 10;
// let n = 5;
// for (let i = 0, i < n ; i++) {
//   console.log(k);
// }

// alert ("Task 2")
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = a--; i < b; i++){
//   console.log(i);
// }

// alert ("Task 3")
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = b; i < a; i--){
//   console.log(i);
// }


// alert ("Task 4")
// let kg = +prompt("1 kgni narxini kiriting");
// for (let i = 0; i < 10; i = i + 0.1) {
//   console.log(Math.floor(i * kg));
// }

// alert ("Task 5")
// let cost = +prompt("1 kgni narxini kiriting");
// for (let i = 1; i < 10; i++) {
//   var kg = i / 10
//   console.log(Math.floor(cost * kg));
// }

// alert ("Task 6")
// let cost = +prompt("1 kgni narxini kiriting");
// for (let i = 0; i < 10; i = i++) {
//   var kg = i / 10
//   console.log(`${kg}kg konfent ${cost * kg}`);
// }

// alert("Task 7")
// let jami = 0
// let a = +prompt("a ni kiriting");
// let b = +prompt("b ni kiriting");
// for (let i = a; i < b; i++){
//   jami = jami + i
//   console.log(jami);
// }

// alert("Task 10")
// let n = 10
// let s = 0
// for (n; n > 0; n--){
//   s +=(1/n)
// }