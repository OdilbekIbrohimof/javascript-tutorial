// alert("task")
let arr2 = []
let n = +prompt("nechta sonli massiv kerak")
let a = +prompt("nechi sonidan boshlangan tasodifiy massiv elememntlari kerak")
let b = +prompt("nechi sonigacha tasodifiy massiv elememntlari kerak")
for (let i = 0; i < n; i++) {
  arr2.push(Math.round(Math.random() * b+a))
}
alert(`Massiv = ${arr2} , Massiv uzunligi = ${arr2.length}`)