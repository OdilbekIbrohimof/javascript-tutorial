window.addEventListener("scroll", (event) => {
  // console.log(window.scrollY); // oynani scroll vaqtidagi balanligini qaytaradi
  // console.log(window.scrollX); // oynani scroll (x o'qida) vaqtidagi balanligini qaytaradi

  if (window.scrollY > 1000 && window.scrollY < 1300) {
    document.querySelector(".animate-box").classList.add("show")
    console.log(window.scrollY);
  } else {
    document.querySelector(".animate-box").classList.remove("show")
    console.log(window.scrollY);
  }
})


//alert("task 1")
// let arr = [
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
//   Math.round(Math.random() * 1000),
// ]

// for (let elem of arr) {
//   if (elem < 99) {
//     console.log(elem ** 2);
//   } else if (elem > 99 && elem < 399) {
//     console.log(elem ** 3);
//   } else {
//     console.log(elem);
//   }
// }

// alert("task 2")
let arr2 = []
let n = +prompt("nechta sonli massiv kerak")
let a = +prompt("nechi sonidan boshlangan tasodifiy massiv elememntlari kerak")
let b = +prompt("nechi sonigacha tasodifiy massiv elememntlari kerak")
for (let i = 0; i < n; i++) {
  arr2.push(Math.round(Math.random() * b+a))
}
alert(`Massiv = ${arr2} , Massiv uzunligi = ${arr2.length}`)
