// let menu = document.querySelector("#menu")
// let currentItem = document.querySelector(".current")
// console.log(menu);
// console.log(currentItem);

// o'zidan keyingi brother tegni olish
// console.log(menu.nextSibling); 
// console.log(currentItem.nextElementSibling);

let tableBlock = document.querySelector(".table") // <table></table>

// let table = document.createElement("table") // <table></table>
// let tr = document.createElement("tr") // <tr></tr>
// for (let i = 0; i < 3; i++) {
//   let td = document.createElement("td") // <td></td>
//   td.innerText = `Item = ${i}` // <td>Item = {i}</td>
//   tr.appenChild(td) // <tr><td></td></tr>
// }
// tabeleBlock.appendChild(tr)
// table.border = "1"
// tableBlock.appendChild(table)

// let title = document.createElement("h1")
// title.innerText = "hello world"
// title.style.color = "#555"
// document.body.appendChild(title)

let singers = [
  {
    name: "Michael Jackson",
    songs: ["Billi Jean", "I love you"]
  },
  {
    name: "One direction",
    songs: ["Kiss you", "Drag me down"]
  },
  {
    name: "Sherali Jo'rayev",
    songs: ["Gul badan", "O'zbegim"]
  }
]

let ol = document.createElement("ol")
for (let i = 0; i < singers.length; i++) {
  let li = document.createElement("li")
  let ul = document.createElement("ul")
  let ulLi = document.createElement("li")
  li.innerText = singers[i].name
  for (let k = 0; k < 2; k++) {
    ulLi.innerText = singers[i].songs[k]
  }
  document.body.appendChild(ol)
  ol.appendChild(li)
  li.appendChild(ul)
  ul.appendChild(ulLi)
}
