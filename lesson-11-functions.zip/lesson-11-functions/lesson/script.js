// arrow function
// let arrowFunc = (x, y, z) => { return (x + y) * y }
// console.log(arrowFunc(2, 2, 5)); // 20
// // agar func 1 ta variable qabul qilsa () qoyish shart emas asosiysi => strelka
// let arrowFunc = x => { return x ** }
// console.log(arrowFunc(2)); // 

// function expersion
// let funExp = function () {
//   console.log("hello");
// }
// funExp()

//callBack function  o'zi function bo'lib turib returnga boshqa function chaqirib ishlatsa bu function CallBack function hisoblanadi
// function sayHi() {
//   console.log("Hi !");
// }

// function sayBye() {
//   console.log("bye bye !");
// }

// function meet(ask , func1 , func2) {
//   if (ask) {
//     return func1()
//   } else {
//     return func2()
//   }
// }
// meet(confirm("hello"),sayHi , sayBye)

// Anonim function
// function () {
//   console.log("hello");
// }
// window.addEventListener("click", function () {
//   console.log("hello");
// })

//ternar operator
// let value = 10 > 0 ? 10 : 0 // ? = if , : = else
// console.log(value);

// let age = +prompt("Age of player")
// let playerName = age > 22 ? "Player on" : "Player off"
// console.log(playerName);

// JavaScript function
// // 1 - declaration
//   function name(params) {
//     x * 2
// }

// // 2 - arrow function
// let func = x => { return x * 2 }
  
// 3- function experession
// let func2 = function (x) { return x * 2 }
  
// 4- callback function
// function call(value, f1, f2) {
//   if (value) return f1()
//   else return f2()
// }
// call(false, () => { alert("f1 is work") }, function() { alert("f2 is work") })

//task 1
// function startWithAb() {
//   let count = 0
//   for (let i = 0; i < 5; i++) {
//     let name1 = prompt("ismni kiriting")
//     if (name1.toLocaleLowerCase().strartsWhith("ab")) {
//       count ++
//     }
//   }
//   return count
// }
// console.log(startWithAb());

// task 2
// function summa(student , money , computer) {
//   let computerMoney = (student * money) / 100 * computer
//   return `vinetka narxi ${student * money - computerMoney} kompuyuterchi uchun biriladigan xizmat haqqi ${ computerMoney}`
// }
// console.log(summa(7, 25000, 10));

// task 3
function getsummAge(studentCount) {
  count = 0
  for (let i = 1; i <= studentCount; i++) {
    let age = +prompt(`Age ? ${i}`)
    count +=age
  }
  return Math.round(count / studentCount) 
}
let students = +prompt("students count ?")
console.log(getsummAge(students));