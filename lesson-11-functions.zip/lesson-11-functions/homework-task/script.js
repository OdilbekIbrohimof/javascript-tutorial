// alert("task 1")
// function PowerA3(a , b , c , d , e) {
//   return `${a ** 3, b ** 3, c ** 3, d ** 3, e** 3}`
// }
// console.log(PowerA3(2.1 , 3.6 , 4.2 , 5 , 6));

// alert("task 2")
// function PowerA234(a, b, c) {
//   return `${a ** 2, b ** 2, c ** 2, a ** 3, b ** 3, c ** 3, a ** 4, b ** 4, c ** 4}`
// }
// console.log(PowerA234(5.2 , 6.5 , 10.3));

// alert("task 3")
// function mean(a , b , c , d ) {
//   return `${(a+b)/2 , (a+c)/2 ,(a+d)/2}`
// }
// console.log(mean(2.1 , 3.6 , 4.2 , 5 ));

// alert("task 4")
// function triangle(a , b , c  ) {
//   return a+b+c 
// }
// console.log(triangle(2.1 , 3.6 , 2.1  ));

// alert("task 6")
// function digitCountSum(a , b , c  ) {
//   return a+b+c , 
// }
// console.log(digitCountSum(5,10,15));

// alert("task 7")
// function invertDigit(a ) {
//   let first = a % 10;
//   let second = (a %100) / 10
//   return  second , first
// }
// console.log(invertDigit(15));

// alert("task 8")
// function addLeftDigit(a) {
//   return `${Math.round(Math.random()* 9) , a}`
// }
// console.log(addLeftDigit(15));

// alert("task 9")
// function addLeftDigit(a) {
//   return `${Math.floor(a) , Math.round(Math.random()* 9)}`
// }
// console.log(addLeftDigit(15));

// alert("task 10")
// function digitCountSum(a , b , c ,d  ) {
//   let e = a
//   let f = b
//   let g = c
//   let h = d
//   a = f
//   b = e
//   c = h
//   d = g
// }
// console.log(digitCountSum(5,10,15 , 20));

// alert("task 11")
// function minMax(x, y) {
//   let a = x
//   let b = y
//   if (a < b) {
//     x = a
//   } else {
//     x = b
//   }
// }
// console.log(minMax(5,10));

// alert("task 13")
// function sortlnc3(a, b , c) {
//   if (a < b && a < c) {
//     let small = a
//   }
//   if (b < a && b < c) {
//     let small = b
//   }
//   if (c < a && c < b) {
//     let small = c
//   }
//   if ((a < b || a > c) && (a > b || a < c)) {
//     let middle = a
//   }
//   if ((b < a || b > c) && (b > a || b < c)) {
//     let middle = b
//   }
//   if ((c < b || c > a) && (c > b || c < a)) {
//     let middle = c
//   }
//   if (a > b && a > c) {
//     let big = a
//   }
//   if (b > a && b > c) {
//     let big = b
//   }
//   if (c > a && c > b) {
//     let big = c
//   }
//   return small , middle , big 
// }
// console.log(sortlnc3(5,10 , 15));

// alert("task 12")
// function sortlnc3(a, b , c) {
//   if (a < b && a < c) {
//     let small = a
//   }
//   if (b < a && b < c) {
//     let small = b
//   }
//   if (c < a && c < b) {
//     let small = c
//   }
//   if ((a < b || a > c) && (a > b || a < c)) {
//     let middle = a
//   }
//   if ((b < a || b > c) && (b > a || b < c)) {
//     let middle = b
//   }
//   if ((c < b || c > a) && (c > b || c < a)) {
//     let middle = c
//   }
//   if (a > b && a > c) {
//     let big = a
//   }
//   if (b > a && b > c) {
//     let big = b
//   }
//   if (c > a && c > b) {
//     let big = c
//   }
//   return big , middle , small 
// }
// console.log(sortlnc3(5,10 , 15));

// alert("task 14")
// function digitCountSum(a , b , c ) {
//   let e = a
//   let f = b
//   let g = c
//   a = f
//   b = g
//   c = e
// }
// console.log(digitCountSum(5,10,15 ));

// alert("task 15")
// function changeDigit(a , b , c ) {
//   let e = a
//   let f = b
//   let g = c
//   a = g
//   b = e
//   c = f
// }
// console.log(changeDigit(5,10,15 ));

// alert("task 16")
// function plusOrMinus(a ) {
//   if (a > 0) {
//     return "+1"
//   }else if (a < 0) {
//     return "-1"
//   } else {
//     return "0"
//   }
// }
// console.log(plusOrMinus(5 ));

// alert("task 18")
// function doiraS(r ) {
//   let PI = 3.1415
//   return PI  * r**2
// }
// console.log(doiraS(5 ));
// console.log(doiraS(15 ));
// console.log(doiraS(25 ));

// alert("task 20")
// function triangleP(a, b) {
//   return a + b + b
// }
// console.log(triangleP(5 , 6 ));

// alert("task 21")
// function sumRange(a, b) {
//   let count = 0
//   if (a > b) {
//     return 0
//   } else {
//     for (let i = a; i < b; i++) {
//       count += i
//     }
//     return count
//   }
// }
// console.log(sumRange(5, 10));

// alert("task 22")
// function calc(a, b , op) {
//   let count = 0
//   if ( op == "+") {
//     return a + b
//   } else if (op == "-") {
//     return a - b
//   } else if (op == "*") {
//     return a * b
//   } else if (op == "/") {
//     return a / b
//   } else if (op == "**") {
//     return a**b
//   } else if (op == "%") {
//     return (a/100)*b
//   }
// }
// console.log(calc(5, 10 , "%"));

// alert("task 24")
// function even(k) {
//   let chekc = k > 0
//   return chekc
// }
// console.log(even(-5));
// console.log(even(24));
// console.log(even(-24));

// alert("task 25")
// function isScuare(k) {
//   for (let i = 0; i > 100; i++) {
//     if (i ** 2 == k) {
//       return true
//       break
//     }
//   }
// }
// console.log(isScuare(6));

// alert("task 26")
// function isPower(k) {
//  for(let i = 0; i < k; i++){
//    if (i ** 5 == k) {
//    return true
//   }
//  }
// }
// console.log(isPower(5));

// alert("task 28")
// function isPrime(n) {
//    if (n > 0) {
//    return true
//   }else {
//      false
//   }
// }
// console.log(isPrime(13));

// alert("task 31")
// function isPalindrom(n) {
//   if (n == palindrom) {
//     return true
//   } else {
//     false
//   }
// }
// console.log(isPalindrom(15));