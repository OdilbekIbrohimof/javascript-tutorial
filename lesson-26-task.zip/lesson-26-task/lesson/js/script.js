//task 1
// let arr = [2, 6, 6, 4, 7, 8, 2, 9, 7, 1, 9]
// let newArr = ""
// for (let i = 0; i < arr.length; i++) {
//   if (!newArr.includes(arr[i])) {
//     newArr += arr[i]
//   }
// }
// console.log(newArr.split("").sort());

//task 2 1900 2040
// function calendarChecker() {
//   let day = +prompt("kunni kiriting")
//   let month = +prompt("oyni kiriting")
//   let year = +prompt("yilni kiriting")
//   let box = 0
//   if (month % 2 == 0 && day < 31) {
//     box += 1
//   }
//   if (month % 1 == 0 && day < 32) {
//     box += 1
//   }

//   if (month > 0 && month < 13) {
//     box += 1
//   }
//   if (year > 1900 && year < 2040) {
//     box += 1
//   }

//   if (box == 3) {
//     return console.log(true);
//   } else {
//     return console.log(false);
//   }
// }

