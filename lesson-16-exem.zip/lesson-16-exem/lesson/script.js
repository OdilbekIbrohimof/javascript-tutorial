//task 1
// let user = {}
// user["name"] = "Jon"
// user["surname"] = "Smit"
// user["name"] = "Pet"
// console.log(user);

// alert("task 2 ishlamadi  ^_^  -_-  ")
// let alpha = prompt("harfni kiriting")
// let num = prompt("sonini kiriting")
// let javob = " "
// if ((alpha == "a" || alpha == "c" || alpha == "e" || alpha == "g") && (num != (num % 2 == 0) || num == 1)) {
//   javob = "black"
// } else {
//   javob = "white"
// }
// if ((alpha == "b" || alpha == "d" || alpha == "f" || alpha == "h") && (num == (num % 2 == 0) || num == 1)) {
//   javob = "white"
// } else {
//   javob = "black"
// }
// alert(javob)

// task 3
// for (let i = 5; i <= 90; i++){
//   if (i % 5 == 0) {
//     console.log(i);
//   }
// }

//task 4
// let first = +prompt("1- urunishning nechi metrligini kiriting")
// let second = +prompt("2- urunishning nechi metrligini kiriting")
// let three = +prompt("3- urunishning nechi metrligini kiriting")
// let big = 0
// let middle = 0
// let small = 0
// if (first > second && first > three) {
//   big = first
// }else if (second > first && second > three) {
//   big = second
// } else if (three > first && three > second) {
//   big = three
// }
// if (first < second && first < three) {
//   small = first
// } else if (second < first && second < three) {
//   small = second
// } else if (three < first && three < second) {
//   small = three
// }
// if (big == second && small == three) {
//   middle = first
// } else if (big == first && small == three) {
//   middle = second
// } else if (big == second && small == first) {
//   middle = three
// }
// console.log(`Player1 ${first + second + three} metrga tepdi ${big} ${middle} ${small}`);

//task 5
// let names = ["john", "defoe", "karl", "enrique", "miguel","roberto"]
// let myFriends = names
// console.log(`mening do'stlarim ${myFriends[4]} ${myFriends[2]} va ${myFriends[5]}`);

//task 6
// for (let i = 7; i > 0; i--){
//   console.log(i);
// }

//task 7
// let str = "Javascript is better"
// for (let i = 0; i < str.length; i++) {
//   console.log(str[i]);
// }

//task 8
// let userName = prompt()
// if (userName == "gani123") {
//   alert("Welcome")
//   break
// } else {
//   alert("Try again")
// }

// task 9
// for (let i = 0; i <= 50; i++){
//   if (i % 2 == 0) {
//     console.log(i);
//   }
// }

//task 10
// let arr = [Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40)]
// console.log(arr);

//task 11
// let arr = [Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40), Math.round(Math.random() * 40)]
// for (let i = 0; i < arr.length; i++){
//   console.log(arr[i]**2 );
// }

//task 12
// let str = prompt("so'z va raqamlar kitriting")
// let num = "1234567890"
// for (let i = 0; i < str.length; i++){
//   for (let j = 0; j < num.length; j++) {
//     if (str[i] == num[j]) {
//       console.log(str[i]);
//     }
//   }
// }

//task 13 
// let str = prompt("so'z kiriting")
// let count = 0
// for (let i = 0; i < str.length; i++) {
//   if (str[i] == "a") {
//     count++
//   }
// }
// if (count > 3) {
//   count = "e"
// }
// console.log(count);

//task 14
// let inputNumber = +prompt("son kiriting")
// let count = 0
// for (let i = 0; i <= 100; i++){
//   if (inputNumber == i) {
//     count ++ 
//   }
// }
// console.log(count);

// task 15
// let first = +prompt("1- reysdagi yo'lovchilar sonini kiriting")
// let second = +prompt("2- reysdagi yo'lovchilar sonini kiriting")
// let three = +prompt("3- reysdagi yo'lovchilar sonini kiriting")
// let summ = `Birinchi reysda ${(first * 120) - ((first / 100) * 3) * 380} sum foyda qilindi`
// let summ2 = `IKkkinchi reysda ${(second *120) - ((second /100) *3) *380} sum foyda qilindi`
// let summ3 = `Uchinchi reysda ${(three * 120) - ((three / 100) * 3) * 380} sum foyda qilindi`
// alert(`${summ} ${summ2} ${summ3} Bu kundagi umumiy foyda ${((first * 120) - ((first / 100) * 3) * 380) + ((second * 120) - ((second / 100) * 3) * 380) + ((three * 120) - ((three / 100) * 3) * 380)} sum bo'ldi`);