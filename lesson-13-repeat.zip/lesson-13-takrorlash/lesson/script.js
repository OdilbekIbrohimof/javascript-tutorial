for (let i = 0; i < 10; i++) {
  console.log(i);
}

//function declaration
function main(x) {
  return x * y
}

//function expression
let f = function (x) {
  return x *x
}

//arrow function 
let func = x => { return x * x }

//CallBack function
function call(f1, f2) {
  if (true) {
    return f1()
  } else {
    return f2()
  }
}

// object 
let user = {
  name: "Odilbek",
  age: 15,
  getInfo: function () { //  bunday qilib ishlatsa ham bo'ladi .. getInfo() {console.log(this.name + " " + this.age);}
    console.log(this.name + " " + this.age);
  }
}
console.log(user.name); // odilbek
console.log(user["age"]); // 15
user.getInfo() // Odilbek 15

let obj = {
  color: "red",
  price: 120,
  model: "apple",
  type: "watch"
}
for (let key in obj) {
  console.log(obj[key]);
}